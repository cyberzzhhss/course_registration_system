
public interface StudentInterface {
	//the method signatures
	public void viewCourse();
	public void viewAvailableCourse();
	public void registerCourse();
	public void withdrawCourse();
	public void viewEnrolledCourse();
	
}
